class Person:
    def __init__(self, name: str): #skillset: dict):
        self.name = name
        self.skillset = dict()


    def get_name(self):
        """Returns the name of the person."""
        return self.name

    def get_skills(self):
        """Returns the skills the person has."""
        return self.skillset

    def add_skill(self, name, level):
        self.skillset[name] = int(level)

    
    def __repr__(self):
        return f"{self.name}: {self.skillset}"

