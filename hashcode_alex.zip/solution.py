from Project import Project 
from Person import Person
from sys import stdin as inp



if __name__ == '__main__':
    people = set()
    projects = set()

    all_roles = set()

    # take the input here 
    num_projects, num_people = list(map(int, inp.readline().strip().split()))

    # adding in the people first ofc ofc 
    for _ in range(num_people):
        # get the name and the number of skills the person has so that we
        # can add each skill to a set

        name, num_skills = inp.readline().strip().split()
        num_skills = int(num_skills)
        # addd skills to this in the next loop
        skills = set()
        for _ in range(num_skills):
            skill = inp.readline().strip()
            skills.add(skill)

        pers = Person(name)
        for skill in skills:
            pers.add_skill(*skill.split())

        people.add(pers)
        print(pers)

    # now get the projects
    for _ in range(num_projects):
        # okay so this is a long list 
        in_ = inp.readline().strip().split()
        name = in_[0]
        days, score, best_before, roles = map(int, in_[1:])
        # fill this with project roles in the next loop
        project_roles = set()
        for _ in range(roles):
            role = inp.readline().strip()
            project_roles.add(role)
        
        prjk = Project(name, days, score, best_before, roles) #, project_roles) # removed this from the constructor
        for role in project_roles:
            prjk.add_role(*role.split())

        projects.add(prjk)

        print(prjk)
        









        






